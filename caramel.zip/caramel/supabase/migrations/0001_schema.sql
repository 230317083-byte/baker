-- Карамель: схема, RLS и автосписание
create type user_role as enum ('seller','manager','admin');
create type user_status as enum ('pending','approved','rejected');
create type order_status as enum ('new','in_work','ready','delivered','archived','cancelled');
create type pay_method as enum ('cash','card','qr','mixed');
create type cash_op_kind as enum ('sale','prepay','surcharge','raw','utilities','opex','other');
create type collection_status as enum ('requested','confirmed','rejected');
create type base_status as enum ('free','reserved_order','reserved_showcase');

create table profiles (
  id uuid primary key references auth.users on delete cascade,
  full_name text not null default '', role user_role not null default 'seller',
  status user_status not null default 'pending', is_owner boolean not null default false,
  created_at timestamptz default now());

create table sources (id serial primary key, name text unique not null, commission_pct numeric(5,2) not null default 0);
create table cakes (id serial primary key, name text not null, active boolean default true);
create table cake_prices (cake_id int references cakes on delete cascade, source_id int references sources on delete cascade,
  price numeric(12,2) not null, primary key (cake_id, source_id));
create table cake_costs (cake_id int primary key references cakes on delete cascade, cost numeric(12,2) not null default 0); -- только админ
create table ingredients (id serial primary key, name text not null, unit text not null default 'г',
  stock numeric(14,3) not null default 0, purchase_price numeric(12,2) not null default 0);
create table bom_items (cake_id int references cakes on delete cascade, ingredient_id int references ingredients,
  qty numeric(14,3) not null, primary key (cake_id, ingredient_id));
create table stock_moves (id bigserial primary key, ingredient_id int references ingredients, delta numeric(14,3) not null,
  reason text not null, ref_id bigint, created_at timestamptz default now());

create table customers (id serial primary key, name text not null, phone text, created_at timestamptz default now());
create table orders (id bigserial primary key, customer_id int references customers, customer_name text, phone text,
  source_id int references sources, pay_method pay_method not null default 'cash', status order_status not null default 'new',
  address text, prepayment numeric(12,2) not null default 0, total numeric(12,2) not null default 0,
  created_by uuid references profiles default auth.uid(), created_at timestamptz default now());
create table order_items (id bigserial primary key, order_id bigint references orders on delete cascade,
  cake_id int references cakes, qty int not null default 1, price numeric(12,2) not null,
  radius_cm numeric(5,1), height_cm numeric(5,1), weight_kg numeric(6,2));

create table cash_shifts (id bigserial primary key, cashier_id uuid references profiles default auth.uid(),
  shift_date date not null default current_date, opening numeric(12,2) not null default 0, closing numeric(12,2),
  unique (cashier_id, shift_date));
create table cash_ops (id bigserial primary key, shift_id bigint references cash_shifts, cashier_id uuid references profiles default auth.uid(),
  kind cash_op_kind not null, amount numeric(12,2) not null, order_id bigint references orders, note text, created_at timestamptz default now());
create table collections (id bigserial primary key, requested_by uuid references profiles default auth.uid(),
  amount numeric(12,2) not null, status collection_status not null default 'requested',
  confirmed_by uuid references profiles, created_at timestamptz default now());

create table bases (id bigserial primary key, cake_id int references cakes, recipe text, weight_kg numeric(6,2),
  radius_cm numeric(5,1), height_cm numeric(5,1), status base_status not null default 'free',
  order_id bigint references orders, baker_id uuid references profiles default auth.uid(), created_at timestamptz default now());
create table showcase_items (id serial primary key, name text not null, weight_kg numeric(6,2), price numeric(12,2) not null, qty int not null default 0);

-- helpers
create function my_role() returns user_role language sql stable security definer set search_path=public as
$$ select role from profiles where id = auth.uid() and status = 'approved' $$;
create function is_admin() returns boolean language sql stable as $$ select coalesce(my_role()='admin', false) $$;
create function is_staff() returns boolean language sql stable as $$ select my_role() is not null $$;

-- новый пользователь -> заявка «Ожидает подтверждения»
create function on_new_user() returns trigger language plpgsql security definer set search_path=public as
$$ begin insert into profiles(id, full_name) values (new.id, coalesce(new.raw_user_meta_data->>'full_name','')); return new; end $$;
create trigger t_new_user after insert on auth.users for each row execute function on_new_user();

-- автосписание по BOM при записи основы
create function autowriteoff() returns trigger language plpgsql security definer set search_path=public as $$
declare r record; begin
  for r in select ingredient_id, qty from bom_items where cake_id = new.cake_id loop
    update ingredients set stock = stock - r.qty where id = r.ingredient_id;
    insert into stock_moves(ingredient_id, delta, reason, ref_id) values (r.ingredient_id, -r.qty, 'автосписание: основа', new.id);
  end loop; return new; end $$;
create trigger t_bases_writeoff after insert on bases for each row execute function autowriteoff();

-- смена владельца (только владелец)
create function transfer_owner(new_owner uuid) returns void language plpgsql security definer set search_path=public as $$
begin
  if not exists (select 1 from profiles where id=auth.uid() and is_owner) then raise exception 'Только Главный администратор'; end if;
  update profiles set is_owner=false where id=auth.uid();
  update profiles set is_owner=true, role='admin', status='approved' where id=new_owner;
end $$;

-- RLS
do $$ declare t text; begin
  foreach t in array array['profiles','sources','cakes','cake_prices','cake_costs','ingredients','bom_items','stock_moves','customers',
   'orders','order_items','cash_shifts','cash_ops','collections','bases','showcase_items'] loop
    execute format('alter table %I enable row level security', t); end loop; end $$;

-- только админ: финансы, себестоимость, склад, источники
create policy adm_costs on cake_costs for all using (is_admin()) with check (is_admin());
create policy adm_ingr on ingredients for all using (is_admin()) with check (is_admin());
create policy adm_bom on bom_items for all using (is_admin()) with check (is_admin());
create policy adm_moves on stock_moves for all using (is_admin()) with check (is_admin());
create policy adm_src_w on sources for all using (is_admin()) with check (is_admin());
create policy adm_collect on collections for all using (is_admin()) with check (is_admin());
create policy adm_profiles on profiles for all using (is_admin()) with check (is_admin());
create policy self_profile on profiles for select using (id = auth.uid());
-- комиссии видит только админ: продавцам выдаём id и название через представление
create view sources_public as select id, name from sources;
grant select on sources_public to authenticated;

-- каталог: читают все одобренные, пишет админ
create policy cakes_r on cakes for select using (is_staff());
create policy cakes_w on cakes for all using (is_admin()) with check (is_admin());
create policy prices_r on cake_prices for select using (is_staff());
create policy prices_w on cake_prices for all using (is_admin()) with check (is_admin());

-- касса: продавец видит и создаёт только свои записи, админ — все; менеджер — ничего
create policy shifts_seller on cash_shifts for select using (my_role()='seller' and cashier_id=auth.uid());
create policy shifts_seller_i on cash_shifts for insert with check (my_role()='seller' and cashier_id=auth.uid());
create policy shifts_admin on cash_shifts for all using (is_admin()) with check (is_admin());
create policy ops_seller on cash_ops for select using (my_role()='seller' and cashier_id=auth.uid());
create policy ops_seller_i on cash_ops for insert with check (my_role()='seller' and cashier_id=auth.uid());
create policy ops_admin on cash_ops for all using (is_admin()) with check (is_admin());
create policy collect_seller_i on collections for insert with check (my_role()='seller' and requested_by=auth.uid() and status='requested');
create policy collect_seller_r on collections for select using (my_role()='seller' and requested_by=auth.uid());

-- заказы/клиенты/цех/витрина: продавец и менеджер читают, создают и правят; удаляет только админ
create policy orders_rw on orders for select using (is_staff());
create policy orders_i on orders for insert with check (my_role() in ('seller','manager','admin'));
create policy orders_u on orders for update using (my_role() in ('seller','manager','admin'));
create policy orders_d on orders for delete using (is_admin());
create policy oi_rw on order_items for select using (is_staff());
create policy oi_i on order_items for insert with check (is_staff());
create policy oi_u on order_items for update using (is_staff());
create policy oi_d on order_items for delete using (is_admin());
create policy cust_rw on customers for select using (is_staff());
create policy cust_i on customers for insert with check (is_staff());
create policy cust_u on customers for update using (is_staff());
create policy cust_d on customers for delete using (is_admin());
create policy bases_r on bases for select using (is_staff());
create policy bases_i on bases for insert with check (is_staff());
create policy bases_u on bases for update using (is_staff());
create policy bases_d on bases for delete using (is_admin());
create policy show_r on showcase_items for select using (is_staff());
create policy show_i on showcase_items for insert with check (is_staff());
create policy show_u on showcase_items for update using (is_staff());
create policy show_d on showcase_items for delete using (is_admin());
-- цены витрины меняет только админ (столбец price защищён триггером)
create function guard_showcase_price() returns trigger language plpgsql as $$
begin if new.price is distinct from old.price and not is_admin() then raise exception 'Менять цены может только администратор'; end if; return new; end $$;
create trigger t_guard_price before update on showcase_items for each row execute function guard_showcase_price();

-- ПЕРВЫЙ АДМИНИСТРАТОР: зарегистрируйтесь, затем выполните:
-- update profiles set role='admin', status='approved', is_owner=true where id='<uuid из auth.users>';
