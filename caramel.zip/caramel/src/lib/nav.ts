export type Role = 'seller' | 'manager' | 'admin'
export const ROLE_RU: Record<Role, string> = { seller: 'Продавец', manager: 'Менеджер', admin: 'Администратор' }
const ALL = [
  ['obzor','Обзор'],['kassa','Касса'],['zakazy','Заказы'],['sklad','Склад'],['ceh','Цех и сборка'],
  ['vitrina','Витрина'],['klienty','Клиенты'],['sebestoimost','Себестоимость'],
  ['istochniki','Источники заказов'],['ceny','Редактор цен витрины'],['polzovateli','Управление пользователями'],
] as const
const ACCESS: Record<Role, string[]> = {
  seller: ['kassa','zakazy','ceh','vitrina','klienty'],
  manager: ['zakazy','klienty','ceh','vitrina'],
  admin: ALL.map(a => a[0]),
}
export const navFor = (r: Role) => ALL.filter(([k]) => ACCESS[r].includes(k)).map(([slug, title]) => ({ slug, title }))
export const canOpen = (r: Role, slug: string) => ACCESS[r].includes(slug)
