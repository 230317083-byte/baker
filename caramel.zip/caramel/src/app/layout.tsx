import './globals.css'
export const metadata = { title: 'Карамель' }
export default function Root({ children }: { children: React.ReactNode }) {
  return <html lang="ru"><body className="bg-moloko text-stone-900">{children}</body></html>
}
