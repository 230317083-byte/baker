import { notFound } from 'next/navigation'
import { supabaseServer } from '@/lib/supabase/server'
import { canOpen, navFor, type Role } from '@/lib/nav'
export default async function Section({ params }: { params: { section: string } }) {
  const sb = supabaseServer()
  const { data: { user } } = await sb.auth.getUser()
  const { data: p } = await sb.from('profiles').select('role').eq('id', user!.id).single()
  const role = p!.role as Role
  if (!canOpen(role, params.section)) notFound()
  const title = navFor(role).find(i => i.slug === params.section)!.title
  return <h1 className="text-2xl font-semibold">{title}</h1> // TODO: модуль
}
