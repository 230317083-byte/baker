import Link from 'next/link'
import { redirect } from 'next/navigation'
import { supabaseServer } from '@/lib/supabase/server'
import { navFor, ROLE_RU, type Role } from '@/lib/nav'
export default async function AppLayout({ children }: { children: React.ReactNode }) {
  const sb = supabaseServer()
  const { data: { user } } = await sb.auth.getUser()
  if (!user) redirect('/login')
  const { data: p } = await sb.from('profiles').select('full_name,role,status').eq('id', user.id).single()
  if (!p || p.status !== 'approved') redirect('/login')
  const items = navFor(p.role as Role) // недоступные пункты вообще не попадают в разметку
  return (
    <div className="flex min-h-screen">
      <aside className="w-60 shrink-0 bg-karamel p-4 text-white">
        <div className="mb-6 text-xl font-semibold">Карамель</div>
        <nav className="space-y-1">{items.map(i => <Link key={i.slug} href={'/' + i.slug} className="block rounded px-3 py-2 hover:bg-white/15">{i.title}</Link>)}</nav>
        <div className="mt-8 text-sm opacity-80">{p.full_name}<br />{ROLE_RU[p.role as Role]}</div>
      </aside>
      <main className="flex-1 p-6">{children}</main>
    </div>)
}
