import { redirect } from 'next/navigation'
import { supabaseServer } from '@/lib/supabase/server'
import { navFor, type Role } from '@/lib/nav'
export default async function Home() {
  const sb = supabaseServer()
  const { data: { user } } = await sb.auth.getUser()
  const { data: p } = await sb.from('profiles').select('role').eq('id', user!.id).single()
  redirect('/' + navFor(p!.role as Role)[0].slug)
}
