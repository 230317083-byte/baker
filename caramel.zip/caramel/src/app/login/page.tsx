'use client'
import { useState } from 'react'
import { supabaseBrowser } from '@/lib/supabase/client'
import { ROLE_RU, type Role } from '@/lib/nav'
export default function Login() {
  const [reg, setReg] = useState(false)
  const [role, setRole] = useState<Role>('seller')
  const [login, setLogin] = useState(''); const [name, setName] = useState(''); const [pass, setPass] = useState('')
  const [msg, setMsg] = useState('')
  const sb = supabaseBrowser()
  async function submit(e: React.FormEvent) {
    e.preventDefault(); setMsg('')
    if (reg) {
      const { error } = await sb.auth.signUp({ email: login, password: pass, options: { data: { full_name: name } } })
      setMsg(error ? 'Не удалось зарегистрироваться: ' + error.message : 'Заявка отправлена. Ожидайте подтверждения администратором.')
      return
    }
    const { data, error } = await sb.auth.signInWithPassword({ email: login, password: pass })
    if (error) return setMsg('Неверный логин или пароль')
    const { data: p } = await sb.from('profiles').select('role,status').eq('id', data.user.id).single()
    if (!p || p.status !== 'approved') { await sb.auth.signOut(); return setMsg('Аккаунт ожидает подтверждения администратором') }
    if (p.role !== role) { await sb.auth.signOut(); return setMsg('Выбрана неверная роль для этого аккаунта') }
    location.href = '/'
  }
  const f = 'w-full rounded border border-stone-300 px-3 py-2'
  return (
    <main className="min-h-screen grid place-items-center p-4">
      <form onSubmit={submit} className="w-full max-w-sm space-y-3">
        <h1 className="text-3xl font-semibold text-karamel">Карамель</h1>
        <p className="text-stone-600">{reg ? 'Заявка на регистрацию' : 'Вход в систему'}</p>
        {!reg && <select className={f} value={role} onChange={e => setRole(e.target.value as Role)}>
          {(Object.keys(ROLE_RU) as Role[]).map(r => <option key={r} value={r}>{ROLE_RU[r]}</option>)}</select>}
        {reg && <input className={f} placeholder="Имя" value={name} onChange={e => setName(e.target.value)} required />}
        <input className={f} type="email" placeholder="Логин (почта)" value={login} onChange={e => setLogin(e.target.value)} required />
        <input className={f} type="password" placeholder="Пароль" value={pass} onChange={e => setPass(e.target.value)} required minLength={6} />
        <button className="w-full rounded bg-karamel py-2 text-white">{reg ? 'Отправить заявку' : 'Войти'}</button>
        {msg && <p className="text-sm text-red-700">{msg}</p>}
        <button type="button" className="text-sm underline" onClick={() => { setReg(!reg); setMsg('') }}>
          {reg ? 'Уже есть аккаунт? Войти' : 'Нет аккаунта? Подать заявку'}</button>
      </form>
    </main>)
}
