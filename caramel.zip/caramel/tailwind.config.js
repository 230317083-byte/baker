module.exports={content:['./src/**/*.{ts,tsx}'],theme:{extend:{colors:{karamel:'#8a4b1f',moloko:'#fbf8f3'}}}}
